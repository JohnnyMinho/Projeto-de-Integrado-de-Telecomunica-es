/**
 * This package collections function definitions that are used in opencsv.
 * Typically, the JDK-provided functions were insufficient because of
 * exceptions thrown.
 */
package com.opencsv.bean.function;