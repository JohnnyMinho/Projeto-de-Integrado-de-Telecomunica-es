package com.opencsv.bean.mocks;

public enum TestEnum {
    TEST1, Test2, test3
}
