package com.opencsv.bean.mocks.recurse;

import com.opencsv.bean.CsvRecurse;

public class FloatRecurse {
    @CsvRecurse
    public float f;
}
