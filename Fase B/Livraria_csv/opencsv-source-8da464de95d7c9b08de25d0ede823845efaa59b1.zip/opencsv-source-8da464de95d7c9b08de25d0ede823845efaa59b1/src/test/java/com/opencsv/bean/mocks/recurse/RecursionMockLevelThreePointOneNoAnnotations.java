package com.opencsv.bean.mocks.recurse;

public class RecursionMockLevelThreePointOneNoAnnotations {
    private boolean booleanLevelThree;

    public boolean isBooleanLevelThree() {
        return booleanLevelThree;
    }

    public void setBooleanLevelThree(boolean booleanLevelThree) {
        this.booleanLevelThree = booleanLevelThree;
    }
}
