package com.opencsv.bean.mocks.recurse;

import com.opencsv.bean.CsvRecurse;

public class DoubleRecurse {
    @CsvRecurse
    public double d;
}
