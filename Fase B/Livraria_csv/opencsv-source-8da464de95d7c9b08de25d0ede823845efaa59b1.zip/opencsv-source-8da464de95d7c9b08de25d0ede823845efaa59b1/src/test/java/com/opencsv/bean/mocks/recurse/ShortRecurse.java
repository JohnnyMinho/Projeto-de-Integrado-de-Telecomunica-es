package com.opencsv.bean.mocks.recurse;

import com.opencsv.bean.CsvRecurse;

public class ShortRecurse {
    @CsvRecurse
    public short s;
}
