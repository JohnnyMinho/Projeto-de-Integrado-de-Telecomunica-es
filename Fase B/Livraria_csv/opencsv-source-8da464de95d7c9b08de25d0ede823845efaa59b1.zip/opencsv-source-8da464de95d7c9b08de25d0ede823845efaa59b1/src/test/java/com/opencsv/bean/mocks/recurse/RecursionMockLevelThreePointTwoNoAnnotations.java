package com.opencsv.bean.mocks.recurse;

public class RecursionMockLevelThreePointTwoNoAnnotations {
    private short shortLevelThree;

    public short getShortLevelThree() {
        return shortLevelThree;
    }

    public void setShortLevelThree(short shortLevelThree) {
        this.shortLevelThree = shortLevelThree;
    }
}
